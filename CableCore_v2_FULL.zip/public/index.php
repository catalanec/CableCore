<?php

require __DIR__ . '/../vendor/autoload.php';

use Antonshapoval\Cablecore\Controllers\CalculateController;

$requestUri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$requestMethod = $_SERVER['REQUEST_METHOD'];

if ($requestUri === '/' && $requestMethod === 'GET') {
    echo "<h1>CableCore Backend v2.0</h1>";
    echo "<p>Sistema funcionando correctamente.</p>";
    exit;
}

if ($requestUri === '/form' && $requestMethod === 'GET') {
    echo '
        <h2>Calculadora CableCore</h2>
        <form method="POST" action="/calculate">
            <input type="number" name="points" placeholder="Puntos de red" required />
            <button type="submit">Calcular</button>
        </form>
    ';
    exit;
}

if ($requestUri === '/calculate' && $requestMethod === 'POST') {
    $controller = new CalculateController();
    $controller->handle();
    exit;
}

http_response_code(404);
echo "Ruta no encontrada.";
