<?php

namespace Antonshapoval\Cablecore\Services;

use Dompdf\Dompdf;

class PdfService
{
    public function generateBudgetPdf($points, $subtotal, $iva, $total)
    {
        $html = "
            <h1>Presupuesto CableCore</h1>
            <p>Puntos de red: $points</p>
            <p>Subtotal: €$subtotal</p>
            <p>IVA (21%): €$iva</p>
            <h2>Total: €$total</h2>
        ";

        $dompdf = new Dompdf();
        $dompdf->loadHtml($html);
        $dompdf->render();

        return $dompdf;
    }
}
