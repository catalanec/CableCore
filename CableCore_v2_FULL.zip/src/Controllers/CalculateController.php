<?php

namespace Antonshapoval\Cablecore\Controllers;

use Antonshapoval\Cablecore\Services\PdfService;

class CalculateController
{
    public function handle()
    {
        $points = intval($_POST['points'] ?? 0);
        $pricePerPoint = 45;

        $subtotal = $points * $pricePerPoint;
        $iva = $subtotal * 0.21;
        $total = $subtotal + $iva;

        $pdfService = new PdfService();
        $dompdf = $pdfService->generateBudgetPdf($points, $subtotal, $iva, $total);

        $dompdf->stream("presupuesto.pdf", ["Attachment" => false]);
    }
}
